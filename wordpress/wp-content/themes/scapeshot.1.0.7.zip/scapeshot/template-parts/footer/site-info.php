<?php
/**
 * The template used for displaying credits
 *
 * @package ScapeShot
 */
?>

<?php
/**
 * scapeshot_credits hook
 * @hooked scapeshot_footer_content - 10
 */
do_action( 'scapeshot_credits' );
